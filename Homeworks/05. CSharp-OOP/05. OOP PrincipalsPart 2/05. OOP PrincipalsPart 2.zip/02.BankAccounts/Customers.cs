﻿namespace _02.BankAccounts
{
    public enum Customers
    {
        Individual,
        Company
    }
}
