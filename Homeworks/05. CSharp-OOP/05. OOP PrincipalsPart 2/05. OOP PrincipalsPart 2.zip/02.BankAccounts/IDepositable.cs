﻿namespace _02.BankAccounts
{
    public interface IDepositable
    {
        void Deposit(decimal amountDeposit);
    }
}