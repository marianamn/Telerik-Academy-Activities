﻿namespace _02.BankAccounts
{
    public interface IWithdrawable
    {
        void Withdraw(decimal amountWithdraw);
    }
}