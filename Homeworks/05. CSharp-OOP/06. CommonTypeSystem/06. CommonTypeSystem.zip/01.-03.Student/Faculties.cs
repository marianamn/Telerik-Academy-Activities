﻿namespace _01._03.Student
{
    public enum Faculties
    {
        IT,
        Science,
        Economy,
        Literature,
        Trade
    }
}