﻿namespace _01._03.Student
{
    public enum Universities
    {
        SU,
        UNWE
    }
}