﻿namespace _01._03.Student
{
    public enum Specialties
    {
        Finance,
        Accounting,
        Journalistics,
        CSharp,
        Java,
        Chemistry
    }
}