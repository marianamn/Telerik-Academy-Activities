1. Rebuild the solution to restore packages.
2. If there is building problebs becouse of JSLint - right click to navigator.js and select Skip on build(item) option. 
2. StyleCop is used for Tasks 1 and 2.
3. JSLint is used for task 3.