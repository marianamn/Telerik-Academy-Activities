﻿namespace _02.BunniesTask
{
    public enum FurType
    {
        NotFluffy = 1,
        ALittleFluffy = 2,
        Fluffy = 3,
        FluffyToTheLimit = 4
    }
}
