﻿namespace _01.BooleanToStingConverter
{
    public class Startup
    {
        public static void Main()
        {
            bool isTrue = false;
            BooleanToSting.CreateConverter(isTrue);
        }
    }
}
