﻿namespace _02.PersonCreator
{
    public enum Gender
    {
        Male,
        Female
    }
}
