1. Rebuild the solution to restore packages.
2. StyleCop is used for CSharp tasks.
3. JSLint is used for for JS tasks.