﻿namespace _01.Chef
{
    public class Carrot : Vegetable
    {
        public Carrot() : base()
        {
        }
    }
}
