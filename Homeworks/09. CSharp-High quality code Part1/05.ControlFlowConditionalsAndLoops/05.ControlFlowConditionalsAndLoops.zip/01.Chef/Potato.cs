﻿namespace _01.Chef
{
    public class Potato : Vegetable
    {
        public Potato() : base()
        {
        }
    }
}
